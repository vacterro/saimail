"""SAIMAIL minimal local entrypoint and persistent local workspace CLI.

The supported local surface: one command that runs the FG-05 end-to-end demo,
the FG-06 TOTAL_FRICTION benchmark, or the V2-01 persistent local workspace
workflow (init, identity, recipient, send, inbox, open) plus a one-command
multi-invocation acceptance harness. No framework, GUI, daemon, web service,
plugin system, adapter abstract, model or hardware dependency.

    python -m saimail_local --help
    python -m saimail_local --version
    python -m saimail_local                      # FG-05 demo
    python -m saimail_local --utility            # FG-06 benchmark
    python -m saimail_local init --workspace DIR --seat SEAT
    python -m saimail_local identity --workspace DIR --export-card CARD.json
    python -m saimail_local recipient add --workspace DIR --alias NAME \
        --card CARD.json --peer-workspace PEER_DIR
    python -m saimail_local send --workspace DIR --to NAME --claim "one line"
    python -m saimail_local send --workspace DIR --redeliver ENVELOPE_ID
    python -m saimail_local inbox --workspace DIR
    python -m saimail_local open --workspace DIR --envelope ENVELOPE_ID
    python -m saimail_local acceptance --root DIR
    python tools/fg05_local_scenario.py          # same FG-05 demo, repo shim

It owns the temporary-root lifecycle and the zero-network tripwire; the LAB
engine it wraps stays pure and offline.
"""

from __future__ import annotations

import argparse
import contextlib
import json
import shutil
import socket
import subprocess
import sys
import tempfile
from importlib import metadata
from pathlib import Path

from sailang import SailangError

_VERSION_FALLBACK = "0.0.2a2"

WR_OK = "OK"
WR_PASS = "PASS"
WR_FAIL = "FAIL"

#: The one-command acceptance harness result contract (spec/17).
ACCEPTANCE_SCHEMA = "LOCAL_WORKSPACE_RESULT_1"
ACCEPTANCE_VERSION = 1


def _version() -> str:
    try:
        return metadata.version("saimail")
    except metadata.PackageNotFoundError:
        version_file = Path(__file__).resolve().parent / "VERSION"
        if version_file.is_file():
            return version_file.read_text(encoding="utf-8").strip()
        return _VERSION_FALLBACK


@contextlib.contextmanager
def no_network(probe: dict):
    """Block and count every socket connection attempt for the enclosed block."""
    original_connect = socket.socket.connect
    original_create = socket.create_connection

    def blocked(*_args, **_kwargs):
        probe["blocked"] = probe.get("blocked", 0) + 1
        raise AssertionError("SAIMAIL local entrypoint attempted a network connection")

    socket.socket.connect = blocked
    socket.create_connection = blocked
    try:
        yield
    finally:
        socket.socket.connect = original_connect
        socket.create_connection = original_create


def _engine():
    from lab import local_scenario

    return local_scenario


def _utility_engine():
    from lab import utility_friction

    return utility_friction


def _workspace_engine():
    from saimail import workspace

    return workspace


def _api_map_path() -> Path:
    return Path(__file__).resolve().parent / "lab" / "stable_local_api.json"


def _run(mode: str, base: Path, probe: dict) -> dict:
    if mode == "utility":
        return _utility_engine().run_utility(base, probe=probe)
    return _engine().run_scenario(base, probe=probe)


def _write_outputs(result: dict, out: Path, mode: str) -> None:
    out.mkdir(parents=True, exist_ok=True)
    if mode == "utility":
        (out / "fg06_utility_result.json").write_text(
            json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        (out / "fg06_utility_summary.md").write_text(
            _utility_engine().render_utility_summary(result) + "\n", encoding="utf-8")
    else:
        (out / "local_scenario_result.json").write_text(
            json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        (out / "local_scenario_summary.md").write_text(
            _engine().render_summary(result) + "\n", encoding="utf-8")


def render(result: dict, mode: str) -> str:
    if mode == "utility":
        return _utility_engine().render_utility_summary(result)
    return _engine().render_summary(result)


# --------------------------------------------------------------------------
# persistent local workspace CLI (V2-01)
# --------------------------------------------------------------------------


def _error_result(command: str, exc: SailangError) -> dict:
    engine = _workspace_engine()
    return {
        "schema": engine.COMMAND_SCHEMA,
        "version": engine.COMMAND_VERSION,
        "command": command,
        "status": exc.code,
        "ok": False,
        "operator_action_required": exc.code in engine.OPERATOR_ACTION_CODES,
        "detail": exc.detail,
    }


def _emit_workspace_result(result: dict, as_json: bool, *, probe: dict | None = None) -> None:
    if probe is not None:
        result["network_attempts"] = probe.get("blocked", 0)
    if as_json:
        print(json.dumps(result, indent=2, sort_keys=True))
    else:
        print(_workspace_engine().render_command(result))


def _dispatch_workspace(command: str, action, as_json: bool) -> int:
    """Run one workspace operation under the local zero-network tripwire."""
    probe: dict = {"blocked": 0}
    try:
        with no_network(probe):
            result = action()
    except SailangError as exc:
        result = _error_result(command, exc)
    _emit_workspace_result(result, as_json, probe=probe)
    return 0 if result.get("ok") else 1


def _cmd_init(args, as_json: bool) -> int:
    engine = _workspace_engine()

    def action():
        return engine.init_workspace(args.workspace, seat=args.seat, custody=args.custody)

    return _dispatch_workspace("init", action, as_json)


def _cmd_custody(args, as_json: bool) -> int:
    engine = _workspace_engine()

    def action():
        if args.custody_action == "status":
            return engine.custody_status(args.workspace)
        return engine.migrate_workspace_custody(args.workspace)

    return _dispatch_workspace(f"custody-{args.custody_action}", action, as_json)


def _cmd_identity(args, as_json: bool) -> int:
    engine = _workspace_engine()

    def action():
        workspace = engine.load_workspace(args.workspace)
        return engine.export_identity_card(workspace, args.export_card)

    return _dispatch_workspace("identity", action, as_json)


def _cmd_recipient(args, as_json: bool) -> int:
    engine = _workspace_engine()

    def action():
        workspace = engine.load_workspace(args.workspace)
        if args.recipient_action == "add":
            card = json.loads(Path(args.card).read_text(encoding="utf-8"))
            return engine.add_recipient(workspace, args.alias, card, args.peer_workspace)
        return engine.list_recipients(workspace)

    return _dispatch_workspace(f"recipient-{args.recipient_action}", action, as_json)


def _cmd_send(args, as_json: bool) -> int:
    engine = _workspace_engine()

    def action():
        workspace = engine.load_workspace(args.workspace)
        if args.redeliver:
            if args.claim or args.record:
                raise SailangError(
                    engine.BAD_INPUT,
                    "an exact replay takes no new content: drop claim/record")
            return engine.redeliver_message(workspace, args.redeliver)
        return engine.send_message(workspace, args.to, claim=args.claim,
                                   record_path=args.record, subject=args.subject,
                                   topic=args.topic, kind=args.kind)

    return _dispatch_workspace("send", action, as_json)


def _cmd_inbox(args, as_json: bool) -> int:
    engine = _workspace_engine()

    def action():
        return engine.list_inbox(engine.load_workspace(args.workspace))

    return _dispatch_workspace("inbox", action, as_json)


def _cmd_open(args, as_json: bool) -> int:
    engine = _workspace_engine()

    def action():
        return engine.open_message(engine.load_workspace(args.workspace), args.envelope)

    return _dispatch_workspace("open", action, as_json)


def _acceptance_runner() -> str:
    """The file to execute for one isolated invocation of this same CLI."""
    return str(Path(__file__).resolve())


class _Acceptance:
    """One isolated multi-invocation V2-01 acceptance run (spec/17)."""

    def __init__(self, base: Path):
        self.base = base
        self.checks: list = []
        self.steps: list = []
        self.results: dict = {}
        self.network_attempts = 0
        self.secret: str | None = None

    def check(self, check_id: str, condition: object, detail: str = "") -> bool:
        ok = bool(condition)
        self.checks.append({"id": check_id, "ok": ok,
                            "detail": "" if ok else (detail or "check failed")})
        return ok

    def step(self, step_id: str, *args: str) -> dict:
        completed = subprocess.run(
            [sys.executable, _acceptance_runner(), *args, "--json"],
            capture_output=True, text=True, check=False,
            cwd=str(self.base))
        payload = None
        try:
            payload = json.loads(completed.stdout)
        except ValueError:
            payload = None
        safe_args = ["<redacted>" if (self.secret and token == self.secret) else token
                     for token in args]
        record = {
            "id": step_id, "args": safe_args,
            "exit_code": completed.returncode,
            "status": (payload or {}).get("status"),
            "ok": completed.returncode == 0 and isinstance(payload, dict),
        }
        self.steps.append(record)
        self.results[step_id] = payload if isinstance(payload, dict) else {}
        self.network_attempts += int((payload or {}).get("network_attempts", 0) or 0)
        return payload or {}

    def run(self) -> dict:
        from saimail import workspace

        self.base.mkdir(parents=True, exist_ok=True)
        ws_a = self.base / "workspace-a"
        ws_b = self.base / "workspace-b"
        card_a = self.base / "identity-a.card.json"
        card_b = self.base / "identity-b.card.json"
        marker = "v2-01 synthetic operator message 7c1d"
        claim = marker + " queue-lease note"
        self.secret = claim

        init_a = self.step("init-a", "init", "--workspace", str(ws_a), "--seat", "SAIMAIL-A")
        init_b = self.step("init-b", "init", "--workspace", str(ws_b), "--seat", "SAIMAIL-B")
        self.check("init_created", init_a.get("status") == workspace.CREATED
                   and init_b.get("status") == workspace.CREATED)
        self.check("workspaces_distinct_roots",
                   ws_a.is_dir() and ws_b.is_dir() and ws_a != ws_b)
        self.check("identities_distinct",
                   init_a.get("identity", {}).get("sender_kid")
                   != init_b.get("identity", {}).get("sender_kid"))

        card_export_a = self.step("card-a", "identity", "--workspace", str(ws_a),
                                  "--export-card", str(card_a))
        card_export_b = self.step("card-b", "identity", "--workspace", str(ws_b),
                                  "--export-card", str(card_b))
        self.check("cards_exported", card_a.is_file() and card_b.is_file()
                   and card_export_a.get("status") == workspace.IDENTITY_CARD_EXPORTED
                   and card_export_b.get("status") == workspace.IDENTITY_CARD_EXPORTED)

        reg_a = self.step("recipient-a", "recipient", "add", "--workspace", str(ws_a),
                          "--alias", "bob", "--card", str(card_b),
                          "--peer-workspace", str(ws_b))
        reg_b = self.step("recipient-b", "recipient", "add", "--workspace", str(ws_b),
                          "--alias", "alice", "--card", str(card_a),
                          "--peer-workspace", str(ws_a))
        self.check("recipients_registered",
                   reg_a.get("status") == workspace.RECIPIENT_ADDED
                   and reg_b.get("status") == workspace.RECIPIENT_ADDED)

        sent = self.step("send", "send", "--workspace", str(ws_a), "--to", "bob",
                         "--claim", claim)
        envelope_id = (sent.get("message") or {}).get("envelope_id")
        received_at = (sent.get("message") or {}).get("received_at")
        self.check("send_accepted", sent.get("status") == "ACCEPTED"
                   and isinstance(envelope_id, str))
        # every step above ran in its own process: this IS the restart boundary

        inbox_one = self.step("inbox-after-send", "inbox", "--workspace", str(ws_b))
        items_one = inbox_one.get("items") or []
        self.check("inbox_one_unread", len(items_one) == 1
                   and items_one[0].get("state") == "UNREAD"
                   and items_one[0].get("envelope_id") == envelope_id,
                   f"items={[(i.get('envelope_id'), i.get('state')) for i in items_one]}")
        self.check("list_metadata_only", marker not in json.dumps(inbox_one))

        opened = self.step("open", "open", "--workspace", str(ws_b),
                           "--envelope", envelope_id)
        self.check("open_exact_message",
                   opened.get("status") == "READ"
                   and (opened.get("record") or {}).get("claim") == claim)
        self.check("open_no_promotion",
                   (opened.get("record") or {}).get("evidence_state")
                   == "EVIDENCE_EXPLICITLY_ABSENT"
                   and (opened.get("record") or {}).get("status") == "U1")

        inbox_read = self.step("inbox-after-open", "inbox", "--workspace", str(ws_b))
        items_read = inbox_read.get("items") or []
        self.check("read_state_persists", len(items_read) == 1
                   and items_read[0].get("state") == "READ")
        self.check("list_metadata_only_after_open", marker not in json.dumps(inbox_read))

        identity_again = self.step("identity-a-again", "identity", "--workspace", str(ws_a))
        self.check("identity_stable_across_invocations",
                   (identity_again.get("identity") or {}).get("sender_kid")
                   == (init_a.get("identity") or {}).get("sender_kid")
                   and (identity_again.get("identity") or {}).get("recipient_kid")
                   == (init_a.get("identity") or {}).get("recipient_kid"))

        replay = self.step("redeliver", "send", "--workspace", str(ws_a),
                           "--redeliver", envelope_id)
        self.check("duplicate_suppressed", replay.get("status") == "DUPLICATE")
        self.check("duplicate_same_received_at",
                   (replay.get("message") or {}).get("received_at") == received_at,
                   f"replay={(replay.get('message') or {}).get('received_at')} "
                   f"original={received_at}")
        inbox_after_replay = self.step("inbox-after-replay", "inbox", "--workspace", str(ws_b))
        items_replay = inbox_after_replay.get("items") or []
        self.check("duplicate_no_second_message",
                   len(items_replay) == 1
                   and sum(1 for i in items_replay if i.get("state") == "UNREAD") == 0)

        outputs = json.dumps(self.results) + "\n" + json.dumps(self.steps)
        private_hexes = [
            json.loads((target / workspace.IDENTITY_DIR / workspace.IDENTITY_NAME)
                       .read_text(encoding="utf-8"))[field]
            for target in (ws_a, ws_b)
            for field in ("sender_private_key", "recipient_private_key")]
        key_in_outputs = any(private_hex in outputs for private_hex in private_hexes)
        marker_on_disk = self._marker_in_files(marker)
        self.check("privacy_key_material_absent_from_outputs", not key_in_outputs)
        self.check("privacy_plaintext_marker_not_on_disk", not marker_on_disk)
        self.check("zero_network_model",
                   self.network_attempts == 0
                   and all(step["ok"] for step in self.steps))

        result = {
            "schema": ACCEPTANCE_SCHEMA,
            "version": ACCEPTANCE_VERSION,
            "status": WR_FAIL,
            "workspaces": {
                "A": {"root": str(ws_a), "seat": "SAIMAIL-A",
                      "sender_kid": (init_a.get("identity") or {}).get("sender_kid"),
                      "recipient_kid": (init_a.get("identity") or {}).get("recipient_kid")},
                "B": {"root": str(ws_b), "seat": "SAIMAIL-B",
                      "sender_kid": (init_b.get("identity") or {}).get("sender_kid"),
                      "recipient_kid": (init_b.get("identity") or {}).get("recipient_kid")},
            },
            "steps": self.steps,
            "checks": self.checks,
            "send": {"envelope_id": envelope_id,
                     "status": sent.get("status"), "received_at": received_at},
            "duplicate": {"status": replay.get("status"),
                          "received_at": (replay.get("message") or {}).get("received_at"),
                          "same_received_at": (replay.get("message") or {}).get("received_at")
                                              == received_at,
                          "messages_after": len(items_replay),
                          "unread_after": sum(1 for i in items_replay
                                              if i.get("state") == "UNREAD")},
            "restart": {"invocations": len(self.steps),
                        "identity_stable": True,
                        "read_state_persisted": True},
            "privacy": {"private_key_material_in_outputs": key_in_outputs,
                        "plaintext_marker_on_disk": marker_on_disk,
                        "plaintext_marker_in_results": False},
            "zero_network_model": {"network_attempts": self.network_attempts,
                                   "provider_calls": 0, "model_calls": 0},
            "artifacts": {"root": str(self.base), "retained": True},
        }
        marker_in_result = marker in json.dumps(result)
        result["privacy"]["plaintext_marker_in_results"] = marker_in_result
        self.check("privacy_plaintext_marker_absent_from_result", not marker_in_result)
        result["status"] = WR_PASS if all(entry["ok"] for entry in self.checks) else WR_FAIL
        return result

    def _marker_in_files(self, marker: str) -> bool:
        needle = marker.encode("utf-8")
        for path in sorted(self.base.rglob("*")):
            if not path.is_file():
                continue
            try:
                if needle in path.read_bytes():
                    return True
            except OSError:
                continue
        return False


def _cmd_acceptance(args, as_json: bool) -> int:
    owned = args.root is None
    base = Path(args.root) if args.root else Path(
        tempfile.mkdtemp(prefix="saimail-workspace-acceptance-"))
    probe = {"blocked": 0, "python": sys.version.split()[0], "platform": sys.platform}
    try:
        if base.exists() and any(base.iterdir()):
            result = {
                "schema": ACCEPTANCE_SCHEMA, "version": ACCEPTANCE_VERSION, "status": WR_FAIL,
                "checks": [{"id": "isolated_root", "ok": False,
                            "detail": f"{base} is not empty; the acceptance root must be fresh"}],
                "artifacts": {"root": str(base), "retained": False},
            }
        else:
            with no_network(probe):
                result = _Acceptance(base).run()
            result["zero_network_model"]["network_attempts"] += probe["blocked"]
            if probe["blocked"]:
                result["status"] = WR_FAIL
            result["artifacts"]["retained"] = bool(args.keep or not owned)
        if args.out is not None:
            out = Path(args.out)
            out.mkdir(parents=True, exist_ok=True)
            (out / "local_workspace_result.json").write_text(
                json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        if as_json:
            print(json.dumps(result, indent=2, sort_keys=True))
        else:
            print(_render_acceptance(result))
        return 0 if result["status"] == WR_PASS else 1
    finally:
        if owned and not args.keep:
            shutil.rmtree(base, ignore_errors=True)


def _render_acceptance(result: dict) -> str:
    checks = result.get("checks") or []
    lines = [
        "V2-01 LOCAL WORKSPACE ACCEPTANCE",
        f"STATUS:   {result.get('status')}",
        f"SCHEMA:   {result.get('schema')} v{result.get('version')}",
        f"STEPS:    {len(result.get('steps') or [])} isolated invocations",
        f"CHECKS:   {sum(1 for c in checks if c['ok'])}/{len(checks)} passed",
        "NETWORK:  " + str((result.get("zero_network_model") or {}).get("network_attempts")),
        f"ROOT:     {(result.get('artifacts') or {}).get('root')}",
    ]
    for entry in checks:
        if not entry["ok"]:
            lines.append(f"  FAILED {entry['id']}: {entry['detail']}")
    return "\n".join(lines)


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="saimail-local",
        description="SAIMAIL minimal local entrypoint (offline demo, utility benchmark "
                    "and persistent local workspace).")
    parser.add_argument("--version", action="store_true", help="print the version and result schemas")
    parser.add_argument("--demo", action="store_true", help="run the FG-05 end-to-end demo (default)")
    parser.add_argument("--utility", action="store_true", help="run the FG-06 utility benchmark")
    parser.add_argument("--out", default=None, help="write machine-readable result and summary to this directory")
    parser.add_argument("--keep", action="store_true", help="retain the temporary workspace and print its path")
    parser.add_argument("--json", action="store_true", help="print the machine-readable result to stdout")
    parser.add_argument("--api-map", action="store_true", help="print the shipped stable API map path")

    sub = parser.add_subparsers(dest="subcommand")

    init_p = sub.add_parser("init", help="initialize a persistent local workspace")
    init_p.add_argument("--workspace", required=True, help="workspace root directory")
    init_p.add_argument("--seat", required=True, help="this workspace's local seat identity")
    init_p.add_argument("--custody", default="raw",
                        help="identity key custody: raw (default, portable) or os-store "
                             "(private keys in the OS credential store; spec/20)")
    init_p.add_argument("--json", action="store_true", dest="sub_json")

    identity_p = sub.add_parser("identity", help="show this workspace's public identity")
    identity_p.add_argument("--workspace", required=True)
    identity_p.add_argument("--export-card", default=None,
                            help="write the public identity card (exchange artifact)")
    identity_p.add_argument("--json", action="store_true", dest="sub_json")

    recipient_p = sub.add_parser("recipient", help="manage explicit local recipients")
    recipient_sub = recipient_p.add_subparsers(dest="recipient_action", required=True)
    recipient_add = recipient_sub.add_parser("add", help="register one recipient by identity card")
    recipient_add.add_argument("--workspace", required=True)
    recipient_add.add_argument("--alias", required=True, help="the local operator name for this recipient")
    recipient_add.add_argument("--card", required=True, help="the recipient's public identity card file")
    recipient_add.add_argument("--peer-workspace", required=True,
                               help="the recipient workspace root used as the local delivery boundary")
    recipient_add.add_argument("--json", action="store_true", dest="sub_json")
    recipient_list = recipient_sub.add_parser("list", help="list registered recipients")
    recipient_list.add_argument("--workspace", required=True)
    recipient_list.add_argument("--json", action="store_true", dest="sub_json")

    send_p = sub.add_parser("send", help="seal and deliver one real local message")
    send_p.add_argument("--workspace", required=True)
    send_p.add_argument("--to", default=None, help="registered recipient alias")
    send_p.add_argument("--claim", default=None, help="one line of operator text (canonical wrapper)")
    send_p.add_argument("--record", default=None, help="existing canonical SAILANG record file")
    send_p.add_argument("--subject", default="local-message")
    send_p.add_argument("--topic", default="local-message")
    send_p.add_argument("--kind", default="PERSONAL_MESSAGE")
    send_p.add_argument("--redeliver", default=None,
                        help="replay one exact outbox container by ENVELOPE_ID")
    send_p.add_argument("--json", action="store_true", dest="sub_json")

    inbox_p = sub.add_parser("inbox", help="list received messages (metadata only)")
    inbox_p.add_argument("--workspace", required=True)
    inbox_p.add_argument("--json", action="store_true", dest="sub_json")

    open_p = sub.add_parser("open", help="explicitly open one exact message")
    open_p.add_argument("--workspace", required=True)
    open_p.add_argument("--envelope", required=True, help="ENVELOPE_ID to open")
    open_p.add_argument("--json", action="store_true", dest="sub_json")

    custody_p = sub.add_parser("custody", help="workspace identity key custody at rest (V3-01)")
    custody_sub = custody_p.add_subparsers(dest="custody_action", required=True)
    custody_status_p = custody_sub.add_parser(
        "status", help="read-only custody diagnosis: mode, backend, loadability")
    custody_status_p.add_argument("--workspace", required=True)
    custody_status_p.add_argument("--json", action="store_true", dest="sub_json")
    custody_migrate_p = custody_sub.add_parser(
        "migrate", help="explicitly move one raw workspace identity into OS-store custody")
    custody_migrate_p.add_argument("--workspace", required=True)
    custody_migrate_p.add_argument("--json", action="store_true", dest="sub_json")

    accept_p = sub.add_parser("acceptance", help="run the isolated multi-invocation V2-01 acceptance")
    accept_p.add_argument("--root", default=None, help="fresh root for the two workspaces")
    accept_p.add_argument("--out", default=None, help="write the machine-readable result here")
    accept_p.add_argument("--keep", action="store_true", help="retain the acceptance root")
    accept_p.add_argument("--json", action="store_true", dest="sub_json")
    return parser


def main(argv=None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)

    if args.version:
        print(f"saimail {_version()}")
        print(f"local scenario: {_engine().SCENARIO} v{_engine().SCENARIO_VERSION} "
              f"({_engine().RESULT_SCHEMA})")
        print(f"utility: {_utility_engine().UTILITY_SCHEMA} v{_utility_engine().UTILITY_VERSION}")
        print(f"local workspace: {_workspace_engine().WORKSPACE_SCHEMA} "
              f"v{_workspace_engine().WORKSPACE_VERSION} ({ACCEPTANCE_SCHEMA})")
        return 0
    if args.api_map:
        print(str(_api_map_path()))
        return 0

    if args.subcommand is not None:
        as_json = bool(getattr(args, "sub_json", False) or args.json)
        if args.subcommand == "init":
            return _cmd_init(args, as_json)
        if args.subcommand == "identity":
            return _cmd_identity(args, as_json)
        if args.subcommand == "recipient":
            return _cmd_recipient(args, as_json)
        if args.subcommand == "send":
            return _cmd_send(args, as_json)
        if args.subcommand == "inbox":
            return _cmd_inbox(args, as_json)
        if args.subcommand == "open":
            return _cmd_open(args, as_json)
        if args.subcommand == "custody":
            return _cmd_custody(args, as_json)
        if args.subcommand == "acceptance":
            return _cmd_acceptance(args, as_json)
        parser.error(f"unknown subcommand {args.subcommand!r}")

    mode = "utility" if args.utility else "demo"
    base = Path(tempfile.mkdtemp(prefix=f"saimail-{mode}-"))
    probe: dict = {"blocked": 0, "python": sys.version.split()[0], "platform": sys.platform}
    try:
        with no_network(probe):
            result = _run(mode, base, probe)
        if probe["blocked"]:
            result["status"] = "FAIL"
            result.setdefault("zero_network_model", {})["network_attempts"] = probe["blocked"]
        result.setdefault("entrypoint", {})["mode"] = mode
        result["entrypoint"]["version"] = _version()
        result["entrypoint"]["api_map"] = str(_api_map_path())
        result.setdefault("artifacts", {})["workspace"] = str(base)
        if args.out is not None:
            _write_outputs(result, Path(args.out), mode)
        if args.json:
            print(json.dumps(result, indent=2, sort_keys=True))
        else:
            print(render(result, mode))
        result["artifacts"]["retained"] = bool(args.keep)
        if args.keep:
            print(f"WORKSPACE RETAINED: {base}")
        status = result.get("status") or result.get("outcome_category")
        return 0 if status in ("PASS", "UTILITY_POSITIVE", "UTILITY_CONDITIONAL", "UTILITY_NEUTRAL") else 1
    finally:
        if not args.keep:
            shutil.rmtree(base, ignore_errors=True)


if __name__ == "__main__":
    raise SystemExit(main())
